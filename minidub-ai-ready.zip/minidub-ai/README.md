# MiniDub AI (starter)

A small local web app: upload a video (max 180 seconds), transcribe with Groq Whisper, translate with Groq chat completions, generate a neural voice with Edge TTS, and mux the voice into the video with FFmpeg.

## Important limitation
This starter does **not** perform lip-sync yet. Groq does not provide lip-sync. For real lip-sync, run MuseTalk 1.5 as a separate GPU service and connect its inference step after TTS. MuseTalk requires its own CUDA/PyTorch environment, model weights and configuration. See https://github.com/TMElyralab/MuseTalk and its README. Do not claim a video is lip-synced unless MuseTalk has successfully processed it.

## Kali Linux setup

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip ffmpeg
cd minidub-ai
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
nano .env
```

Put your Groq API key in `.env`:
`GROQ_API_KEY=your_real_key`

Run:
```bash
uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```
Open http://127.0.0.1:8000

## Notes
- Groq audio upload size limits apply. The app rejects extracted audio larger than 24 MB.
- The app replaces original audio with the generated dub; background music preservation/mixing is not included yet.
- Edge TTS uses Microsoft's online speech service and requires internet. Hindi voice: `hi-IN-SwaraNeural`; Urdu voice: `ur-PK-UzmaNeural`.
- Roman Urdu pronunciation from an Urdu TTS voice may be imperfect. Hindi is the better first demo target.
- Keep `.env` private. Never put the Groq key in browser JavaScript or commit it to Git.
- Only upload videos and voices you own or have permission to process.
