import os, json, uuid, shutil, asyncio, subprocess
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv
from groq import Groq
import edge_tts

load_dotenv()
BASE = Path(__file__).parent
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"
UPLOADS.mkdir(exist_ok=True)
OUTPUTS.mkdir(exist_ok=True)

app = FastAPI(title="MiniDub AI")
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")
client = Groq(api_key=os.getenv("GROQ_API_KEY"))
CHAT_MODEL = os.getenv("GROQ_CHAT_MODEL", "llama-3.3-70b-versatile")

def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode:
        raise RuntimeError(p.stderr[-2500:] or "Command failed")
    return p.stdout

def duration_seconds(path: Path) -> float:
    raw = run([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(path)
    ]).strip()
    return float(raw)

def translate(text: str, target: str) -> str:
    if target == "Hindi":
        instruction = "Translate into natural, conversational Hindi written in Devanagari script."
    elif target == "Roman Urdu":
        instruction = "Translate into natural Pakistani conversational Urdu written ONLY in Roman Urdu (Latin alphabet), not Urdu script."
    else:
        instruction = "Translate into natural conversational English."
    result = client.chat.completions.create(
        model=CHAT_MODEL,
        temperature=0.2,
        messages=[
            {"role":"system","content":"You are a precise video dubbing translator. Preserve meaning, names, tone and short spoken phrasing. Return only the translated text. " + instruction},
            {"role":"user","content":text}
        ]
    )
    return result.choices[0].message.content.strip()

async def make_tts(text: str, target: str, out: Path):
    # Hindi voice is natural Hindi. Roman Urdu is spoken by an Urdu neural voice;
    # Roman spelling may need manual correction for pronunciation.
    voice = "hi-IN-SwaraNeural" if target == "Hindi" else "ur-PK-UzmaNeural"
    communicate = edge_tts.Communicate(text, voice)
    await communicate.save(str(out))

@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE / "static" / "index.html").read_text()

@app.post("/dub")
async def dub(video: UploadFile = File(...), target: str = Form(...)):
    if not os.getenv("GROQ_API_KEY"):
        raise HTTPException(500, "GROQ_API_KEY .env file mein set karein.")
    if target not in {"Hindi", "Roman Urdu"}:
        raise HTTPException(400, "Unsupported target language.")
    ext = Path(video.filename or "video.mp4").suffix.lower()
    if ext not in {".mp4", ".mov", ".mkv", ".webm"}:
        raise HTTPException(400, "MP4, MOV, MKV ya WEBM video upload karein.")
    job = uuid.uuid4().hex
    src = UPLOADS / f"{job}{ext}"
    audio = UPLOADS / f"{job}.wav"
    tts = OUTPUTS / f"{job}_voice.mp3"
    output = OUTPUTS / f"{job}_dubbed.mp4"
    with src.open("wb") as f:
        shutil.copyfileobj(video.file, f)
    try:
        dur = duration_seconds(src)
        if dur > 180:
            raise HTTPException(400, "Video 3 minutes (180 seconds) se zyada hai.")
        if dur <= 0:
            raise HTTPException(400, "Video duration read nahi ho saki.")
        run(["ffmpeg","-y","-i",str(src),"-vn","-ac","1","-ar","16000",str(audio)])
        if audio.stat().st_size > 24 * 1024 * 1024:
            raise HTTPException(400, "Audio Groq upload limit se bara hai. Chhoti/lower-bitrate video try karein.")
        with audio.open("rb") as f:
            transcription = client.audio.transcriptions.create(
                file=(audio.name, f.read()),
                model="whisper-large-v3",
                response_format="verbose_json"
            )
        original_text = transcription.text.strip()
        if not original_text:
            raise HTTPException(400, "Video mein speech detect nahi hui.")
        translated = translate(original_text, target)
        await make_tts(translated, target, tts)
        # MVP mix: replace original audio with translated voice.
        # Lip-sync is NOT applied in this starter; see README for MuseTalk setup.
        run([
            "ffmpeg","-y","-i",str(src),"-i",str(tts),
            "-map","0:v:0","-map","1:a:0",
            "-af","apad","-c:v","copy","-c:a","aac","-b:a","192k",
            "-shortest",str(output)
        ])
        return {
            "job_id": job,
            "original_text": original_text,
            "translated_text": translated,
            "download_url": f"/download/{job}"
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Processing error: {str(e)}")
    finally:
        audio.unlink(missing_ok=True)
        tts.unlink(missing_ok=True)
        src.unlink(missing_ok=True)

@app.get("/download/{job_id}")
def download(job_id: str):
    path = OUTPUTS / f"{job_id}_dubbed.mp4"
    if not path.exists():
        raise HTTPException(404, "Output file nahi mila.")
    return FileResponse(path, media_type="video/mp4", filename="minidub_dubbed.mp4")
